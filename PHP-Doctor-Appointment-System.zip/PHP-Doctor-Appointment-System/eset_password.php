<?php
include_once 'assets/conn/dbconnect.php';

if (isset($_GET['token'])) {
    $token = mysqli_real_escape_string($con, $_GET['token']);
    $query = "SELECT * FROM patient WHERE reset_token = '$token' AND reset_expiry > NOW()";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    
    if ($row) {
        if (isset($_POST['reset'])) {
            $password = mysqli_real_escape_string($con, $_POST['password']);
            
            $query = "UPDATE patient SET password = '$password', reset_token = NULL, reset_expiry = NULL WHERE reset_token = '$token'";
            mysqli_query($con, $query);
            echo '<script>alert("Password reset successfully. You can now login with your new password.");</script>';
            header("Location: index.php"); 
            exit;
        }
    } else {
        echo '<script>alert("Password reset link has expired or is invalid.");</script>';
        header("Location: index.php"); 
        exit;
    }
} else {
    echo '<script>alert("Invalid request.");</script>';
    header("Location: index.php"); 
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <h2>Reset Password</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter new password" required>
                    </div>
                    <button type="submit" class="btn btn-primary" name="reset">Reset Password</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
