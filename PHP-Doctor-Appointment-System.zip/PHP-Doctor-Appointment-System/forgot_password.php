<?php
include_once 'assets/conn/dbconnect.php';
session_start();

if (isset($_POST['reset'])) {
    $icPatient = mysqli_real_escape_string($con, $_POST['icPatient']);
    $patientEmail = mysqli_real_escape_string($con, $_POST['patientEmail']);
    $newPassword = mysqli_real_escape_string($con, $_POST['newPassword']);
    
    $res = mysqli_query($con, "SELECT * FROM patient WHERE icPatient = '$icPatient' AND patientEmail = '$patientEmail'");
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    
    if ($row) {
        $update = mysqli_query($con, "UPDATE patient SET password = '$newPassword' WHERE icPatient = '$icPatient' AND patientEmail = '$patientEmail'");
        if ($update) {
            ?>
            <script type="text/javascript">
                alert('Password reset successfully. Please login with your new password.');
                window.location.href = 'index.php';
            </script>
            <?php
        } else {
            ?>
            <script type="text/javascript">
                alert('Failed to reset password. Please try again.');
            </script>
            <?php
        }
    } else {
        ?>
        <script type="text/javascript">
            alert('Invalid IC number or email. Please try again.');
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <h2>Forgot Password</h2>
                <form method="POST" action="forgot_password.php">
                    <div class="form-group">
                        <label for="icPatient">IC Number</label>
                        <input type="text" class="form-control" name="icPatient" placeholder="IC Number" required>
                    </div>
                    <div class="form-group">
                        <label for="patientEmail">Email</label>
                        <input type="email" class="form-control" name="patientEmail" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label for="newPassword">New Password</label>
                        <input type="password" class="form-control" name="newPassword" placeholder="New Password" required>
                    </div>
                    <button type="submit" name="reset" class="btn btn-primary">Reset Password</button>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
